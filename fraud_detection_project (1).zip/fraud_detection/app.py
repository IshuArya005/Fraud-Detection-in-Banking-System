import json, sqlite3, hashlib, datetime as dt
import joblib, numpy as np, pandas as pd
import plotly.express as px, plotly.graph_objects as go
import streamlit as st
from retrain import retrain
import style

st.set_page_config(page_title="Bank Fraud Detection", page_icon="🏦", layout="wide")
style.inject()
CMAP = {"Legit": "#38bdf8", "Fraud": "#f43f5e"}

# ---------- login (demo accounts) ----------
def _h(x): return hashlib.sha256(x.encode()).hexdigest()
USERS = {"admin": ("240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9", "admin"), "analyst": ("20249749412d73a3f5799f6f1dcf910e7b4aa3ce4de133b1f8a63c044792a4e9", "analyst")}
if "user" not in st.session_state:
    _, mid, _ = st.columns([1, 1.1, 1])
    style.title("🛡️ FraudGuard", "Sign in to the fraud monitoring console", mid)
    u = mid.text_input("Username"); pw = mid.text_input("Password", type="password")
    mid.caption("Demo accounts: admin / admin123 (full access) · analyst / analyst123 (no retraining)")
    if mid.button("Login", type="primary"):
        if u in USERS and USERS[u][0] == _h(pw):
            st.session_state.user, st.session_state.role = u, USERS[u][1]; st.rerun()
        else:
            mid.error("Invalid username or password")
    st.stop()
role = st.session_state.role


@st.cache_resource
def load():
    return joblib.load("model/fraud_model.joblib")


try:
    art = load()
except FileNotFoundError:
    st.error("Model not found. Run `python train_model.py` first."); st.stop()

feats, medians = art["features"], art["medians"]

# ---------- alert database (SQLite) ----------
db = sqlite3.connect("alerts.db", check_same_thread=False)
db.execute("""CREATE TABLE IF NOT EXISTS alerts(id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT,
              amount REAL, score REAL, status TEXT, details TEXT)""")
db.commit()


def log_alert(row, score, status):
    db.execute("INSERT INTO alerts(ts,amount,score,status,details) VALUES(?,?,?,?,?)",
               (dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), float(row["amount"]), float(score),
                status, json.dumps({k: float(v) for k, v in row.items()})))
    db.commit()


# ---------- sidebar ----------
st.sidebar.markdown('<div class="brand">🛡️ FraudGuard<span>Bank fraud intelligence</span></div>', unsafe_allow_html=True)
st.sidebar.write(f"👤 {st.session_state.user} ({role})")
if st.sidebar.button("Logout"):
    del st.session_state["user"]; st.rerun()
pages = ["Dashboard", "Check transaction", "Live simulator", "Alerts & case review", "Batch scan (CSV)",
         "Model comparison", "Threshold optimizer", "Anomaly detection"] + (["Retrain model"] if role == "admin" else [])
page = st.sidebar.radio("Navigate", pages)
model_name = st.sidebar.selectbox("Model", list(art["models"]), index=list(art["models"]).index(art["best"]))
thr = st.sidebar.slider("Alert threshold", 0.05, 0.95, 0.50, 0.05,
                        help="Lower = catch more fraud but more false alarms")
model = art["models"][model_name]


def score(df):
    return model.predict_proba(df[feats])[:, 1]


def explain(row):
    """How much each feature pushes the score up (+) or down (-) vs a typical transaction."""
    base = score(pd.DataFrame([row]))[0]
    out = {}
    for f in feats:
        r = dict(row); r[f] = medians[f]
        out[f] = base - score(pd.DataFrame([r]))[0]
    return base, pd.Series(out).sort_values()


def status_of(p):
    return "FRAUD" if p >= thr else ("REVIEW" if p >= thr * .6 else "OK")


@st.cache_data
def test_scores(name):
    t = pd.read_csv("data/test_set.csv"); t["score"] = art["models"][name].predict_proba(t[feats])[:, 1]
    return t


# =============== PAGES ===============
if page == "Dashboard":
    style.title("Fraud monitoring dashboard", f"Live overview · model: {model_name} · alert threshold {thr:.0%}")
    t = test_scores(model_name); t["flagged"] = t.score >= thr
    tp = int((t.flagged & (t.Class == 1)).sum()); fp = int((t.flagged & (t.Class == 0)).sum())
    fn = int((~t.flagged & (t.Class == 1)).sum())
    saved = t.loc[t.flagged & (t.Class == 1), "amount"].sum(); missed = t.loc[~t.flagged & (t.Class == 1), "amount"].sum()
    a, b, c, d = st.columns(4)
    a.metric("Transactions", f"{len(t):,}"); b.metric("Fraud caught", tp, f"of {tp + fn} actual")
    c.metric("False alarms", fp); d.metric("Money saved", f"{saved:,.0f}", f"-{missed:,.0f} missed", delta_color="off")
    rep = (f"<h1>FraudGuard report</h1><p>Generated {dt.datetime.now():%Y-%m-%d %H:%M} by {st.session_state.user}</p>"
           f"<p>Model: {model_name} | Threshold: {thr}</p><ul><li>Transactions analysed: {len(t):,}</li>"
           f"<li>Fraud caught: {tp} of {tp + fn}</li><li>False alarms: {fp}</li>"
           f"<li>Money saved: {saved:,.0f}</li><li>Money missed: {missed:,.0f}</li></ul>")
    st.download_button("📄 Download report (HTML)", rep, "fraud_report.html", "text/html")
    l, r = st.columns(2)
    h = t.groupby("hour").agg(fraud_rate=("Class", "mean")).reset_index()
    l.plotly_chart(px.bar(h, x="hour", y="fraud_rate", title="Fraud rate by hour of day", color_discrete_sequence=["#818cf8"]))
    r.plotly_chart(px.histogram(t.assign(Label=t.Class.map({0: "Legit", 1: "Fraud"})), x="score", color="Label", color_discrete_map=CMAP, nbins=40,
                                barmode="overlay", log_y=True, title="Risk score distribution"))
    sm = t.sample(3000, random_state=1).copy(); sm["Label"] = sm.Class.map({0: "Legit", 1: "Fraud"})
    st.plotly_chart(px.scatter(sm, x="distance_from_home_km", y="amount", color="Label", color_discrete_map=CMAP,
                               log_x=True, log_y=True, title="Amount vs distance from home"))

elif page == "Check transaction":
    style.title("Check a transaction")
    c1, c2 = st.columns(2)
    row = dict(amount=c1.number_input("Amount", 0.0, 1e6, 250.0), hour=c1.slider("Hour of day", 0, 23, 14),
               distance_from_home_km=c1.number_input("Distance from home (km)", 0.0, 20000.0, 5.0),
               txns_last_24h=c1.number_input("Transactions in last 24h", 0, 100, 2),
               account_age_days=c2.number_input("Account age (days)", 0, 20000, 900),
               is_international=int(c2.checkbox("International")), card_present=int(c2.checkbox("Card present", True)),
               merchant_risk=c2.slider("Merchant risk score", 0.0, 1.0, 0.3))
    if st.button("Analyze", type="primary"):
        p, contrib = explain(row); s = status_of(p)
        g = go.Figure(go.Indicator(mode="gauge+number", value=p * 100, number={"suffix": "%"},
                      title={"text": "Fraud risk"}, gauge={"axis": {"range": [0, 100]},
                      "threshold": {"line": {"color": "red", "width": 4}, "value": thr * 100},
                      "bar": {"color": "#f43f5e" if s == "FRAUD" else "#f59e0b" if s == "REVIEW" else "#10b981"}}))
        l, r = st.columns(2); l.plotly_chart(g)
        cdf = contrib.reset_index(); cdf.columns = ["feature", "impact"]
        r.plotly_chart(px.bar(cdf, x="impact", y="feature", orientation="h", title="Why this score?",
                              color=cdf.impact > 0, color_discrete_map={True: "#f43f5e", False: "#10b981"}).update_layout(showlegend=False))
        head, sub = {"FRAUD": ("🚨 FRAUD ALERT", "Block the payment and contact the customer"),
                     "REVIEW": ("⚠️ Suspicious activity", "Send to an analyst for manual review"),
                     "OK": ("✅ Looks legitimate", "No action needed")}[s]
        style.banner(s, head, f"{sub} · risk score {p:.1%} · threshold {thr:.0%}")
        if s != "OK":
            log_alert(row, p, s); st.caption("Saved to Alerts & case review.")
            if s == "FRAUD": st.toast("📲 SMS alert sent to customer (simulated)")

elif page == "Live simulator":
    style.title("Live transaction stream (simulation)")
    n = st.slider("Number of transactions", 10, 200, 50)
    if st.button("Start simulation", type="primary"):
        t = test_scores(model_name).sample(n, random_state=None).reset_index(drop=True)
        t["status"] = t.score.map(status_of)
        bar, box, rows = st.progress(0), st.empty(), []
        for i, r in t.iterrows():
            rows.append(r); bar.progress((i + 1) / n)
            if r.status != "OK":
                log_alert({f: r[f] for f in feats}, r.score, r.status)
            if i % 5 == 0 or i == n - 1:
                box.dataframe(pd.DataFrame(rows).tail(12)[["amount", "hour", "distance_from_home_km", "score", "status"]])
        st.success(f"Processed {n} transactions - {int((t.status == 'FRAUD').sum())} fraud alerts, "
                   f"{int((t.status == 'REVIEW').sum())} for review. Alerts saved.")

elif page == "Alerts & case review":
    style.title("Alerts & case review")
    a = pd.read_sql("SELECT * FROM alerts ORDER BY id DESC", db)
    if a.empty:
        st.info("No alerts yet. Analyze transactions or run the simulator.")
    else:
        f = st.multiselect("Status filter", sorted(a.status.unique()), default=sorted(a.status.unique()))
        v = a[a.status.isin(f)]; st.dataframe(v.drop(columns="details"))
        st.download_button("Export alerts CSV", v.to_csv(index=False), "alerts.csv")
        st.subheader("Review a case")
        cid = st.selectbox("Alert ID", v.id.tolist())
        if cid:
            rec = a[a.id == cid].iloc[0]; st.json(json.loads(rec.details))
            b1, b2, b3 = st.columns(3)
            for col, label, s in [(b1, "✅ Confirm fraud", "CONFIRMED_FRAUD"), (b2, "❌ False alarm", "FALSE_ALARM"),
                                  (b3, "⏳ Escalate", "ESCALATED")]:
                if col.button(label):
                    db.execute("UPDATE alerts SET status=? WHERE id=?", (s, int(cid))); db.commit(); st.rerun()

elif page == "Batch scan (CSV)":
    style.title("Batch scan")
    st.caption(f"CSV columns needed: {', '.join(feats)}")
    st.download_button("Download sample CSV", pd.read_csv("data/test_set.csv").head(200).drop(columns="Class").to_csv(index=False), "sample.csv")
    up = st.file_uploader("Upload CSV", type="csv")
    if up:
        df = pd.read_csv(up); miss = [c for c in feats if c not in df.columns]
        if miss: st.error(f"Missing columns: {miss}")
        else:
            df["fraud_score"] = score(df); df["status"] = df.fraud_score.map(status_of)
            a, b, c = st.columns(3); a.metric("Rows", len(df)); b.metric("Fraud", int((df.status == "FRAUD").sum()))
            c.metric("Review", int((df.status == "REVIEW").sum()))
            st.plotly_chart(px.histogram(df, x="fraud_score", nbins=40, title="Risk scores"))
            st.dataframe(df.sort_values("fraud_score", ascending=False).head(200))
            st.download_button("Download results", df.to_csv(index=False), "scored.csv")

elif page == "Model comparison":
    style.title("Model comparison")
    res = pd.DataFrame(art["results"]).T.round(3); st.dataframe(res)
    st.success(f"Best model by PR-AUC: {art['best']}")
    l, r = st.columns(2); fr, fp_ = go.Figure(), go.Figure()
    for n, c in art["curves"].items():
        fr.add_trace(go.Scatter(x=c["fpr"], y=c["tpr"], name=n)); fp_.add_trace(go.Scatter(x=c["rec"], y=c["prec"], name=n))
    fr.update_layout(title="ROC curve", xaxis_title="False positive rate", yaxis_title="True positive rate")
    fp_.update_layout(title="Precision-Recall curve", xaxis_title="Recall", yaxis_title="Precision")
    l.plotly_chart(fr); r.plotly_chart(fp_)
    y, p = art["y_te"], art["proba"][model_name] >= thr
    cm = pd.DataFrame([[((y == 0) & ~p).sum(), ((y == 0) & p).sum()], [((y == 1) & ~p).sum(), ((y == 1) & p).sum()]],
                      index=["Actual legit", "Actual fraud"], columns=["Pred legit", "Pred fraud"])
    st.plotly_chart(px.imshow(cm, text_auto=True, title=f"Confusion matrix - {model_name} @ threshold {thr}"))

elif page == "Threshold optimizer":
    style.title("Cost-based threshold optimizer")
    st.write("Missing fraud and annoying customers with false alarms both cost money. Find the best balance.")
    c1, c2 = st.columns(2)
    miss = c1.number_input("Cost of a missed fraud", 1.0, 1e6, 500.0); alarm = c2.number_input("Cost of a false alarm", 0.1, 1e5, 10.0)
    y, p = art["y_te"], art["proba"][model_name]; ts = np.arange(0.02, 0.99, 0.01)
    cost = [miss * ((p < t) & (y == 1)).sum() + alarm * ((p >= t) & (y == 0)).sum() for t in ts]
    best_t = ts[int(np.argmin(cost))]
    st.plotly_chart(px.line(x=ts, y=cost, labels={"x": "Threshold", "y": "Total cost"}, title="Total cost vs threshold")
                    .add_vline(x=best_t, line_color="green").add_vline(x=thr, line_color="red", line_dash="dot"))
    st.success(f"Recommended threshold: {best_t:.2f}  (cost {min(cost):,.0f}) vs current {thr:.2f}  (cost "
               f"{miss * ((p < thr) & (y == 1)).sum() + alarm * ((p >= thr) & (y == 0)).sum():,.0f})")

elif page == "Anomaly detection":
    from sklearn.metrics import average_precision_score
    style.title("Anomaly detection (unsupervised layer)")
    st.write("Isolation Forest never sees fraud labels; it flags transactions that look unusual. "
             "It can surface new fraud patterns the supervised model has not learned.")
    t = test_scores(model_name); lo, hi = art["iso_range"]
    t["anomaly"] = np.clip((-art["iso"].score_samples(t[feats]) - lo) / (hi - lo), 0, 1)
    a1, b1 = st.columns(2)
    a1.metric("Isolation Forest PR-AUC", f"{average_precision_score(t.Class, t.anomaly):.3f}")
    b1.metric(f"{model_name} PR-AUC", f"{average_precision_score(t.Class, t.score):.3f}")
    q = st.slider("Treat top X% most unusual as anomalies", 1, 20, 5)
    new = t[(t.anomaly >= t.anomaly.quantile(1 - q / 100)) & (t.score < thr)]
    st.write(f"**{len(new)}** transactions look unusual but were not flagged by the supervised model "
             f"({int(new.Class.sum())} of them are real fraud). These are candidates for manual review.")
    sm = t.sample(3000, random_state=1).copy(); sm["Label"] = sm.Class.map({0: "Legit", 1: "Fraud"})
    st.plotly_chart(px.scatter(sm, x="score", y="anomaly", color="Label", color_discrete_map=CMAP, title="Supervised score vs anomaly score"))
    st.dataframe(new.sort_values("anomaly", ascending=False).head(50)[feats + ["score", "anomaly", "Class"]])

elif page == "Retrain model":
    style.title("Retrain model (admin only)")
    if "flash" in st.session_state: st.success(st.session_state.pop("flash"))
    st.caption(f"Upload a labeled CSV with columns: {', '.join(feats)}, Class (0 = legit, 1 = fraud)")
    st.download_button("Download sample training data", pd.read_csv("data/train_set.csv").head(20000).to_csv(index=False), "train_sample.csv")
    up = st.file_uploader("Labeled CSV", type="csv")
    if up:
        d = pd.read_csv(up)
        if [c for c in feats + ["Class"] if c not in d.columns]: st.error("Missing required columns.")
        elif d["Class"].nunique() < 2: st.error("Data must contain both fraud and legit rows.")
        else:
            st.write(f"{len(d):,} rows, fraud rate {d['Class'].mean():.2%}")
            if st.button("Train & add model", type="primary"):
                with st.spinner("Training..."):
                    n = retrain(d, art); test_scores.clear()
                st.session_state["flash"] = f"'{n}' trained and saved. Select it in the sidebar or see Model comparison."
                st.rerun()
