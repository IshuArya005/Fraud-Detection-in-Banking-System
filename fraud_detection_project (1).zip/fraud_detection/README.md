# FraudGuard - Banking Fraud Detection (ML + Streamlit)

## Run
```bash
pip install -r requirements.txt
python train_model.py
streamlit run app.py
```

## Pages
1. **Dashboard** - KPIs (fraud caught, false alarms, money saved), fraud by hour, score distribution
2. **Check transaction** - risk gauge + "Why this score?" explanation; suspicious ones are logged
3. **Live simulator** - streams transactions in real time, auto-logs alerts
4. **Alerts & case review** - SQLite alert log; confirm fraud / false alarm / escalate; CSV export
5. **Batch scan** - upload CSV, score all rows, download results
6. **Model comparison** - Logistic Regression vs Random Forest vs Gradient Boosting (ROC, PR, confusion matrix)
7. **Threshold optimizer** - pick the alert threshold with the lowest business cost

8. **Anomaly detection** - Isolation Forest (unsupervised) finds unusual transactions the main model missed
9. **Retrain model** (admin) - upload labeled CSV, train a new model, compare it with the others
10. **Login with roles** - admin / admin123, analyst / analyst123
11. **Reports and API** - HTML report download; REST API: `uvicorn api:app --reload` then open `http://127.0.0.1:8000/docs`

## Tech
Python, scikit-learn, Streamlit, Plotly, SQLite. Class imbalance handled with class weights; PR-AUC used for model selection.
