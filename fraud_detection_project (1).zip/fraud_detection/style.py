"""Look and feel: CSS + small HTML helpers."""
import streamlit as st

CSS = """<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
html, body, [class*="css"] { font-family: 'Inter', sans-serif; }
#MainMenu, footer { visibility: hidden; }
header[data-testid="stHeader"] { background: transparent; }
.block-container { padding-top: 1.8rem; max-width: 1250px; }
.stApp { background: radial-gradient(1200px 600px at 10% -10%, #16233f 0%, #0b1120 55%); }
section[data-testid="stSidebar"] { background: linear-gradient(180deg,#0f172a,#0a0f1d); border-right: 1px solid #1e293b; }
.brand { font-size: 1.4rem; font-weight: 700; color: #e2e8f0; padding: .2rem 0 .8rem; }
.brand span { display: block; font-size: .7rem; font-weight: 500; color: #64748b; letter-spacing: .08em; text-transform: uppercase; margin-top: 2px; }
.fg-title { font-size: 2rem; font-weight: 700; line-height: 1.2; background: linear-gradient(90deg,#22d3ee,#818cf8); -webkit-background-clip: text; -webkit-text-fill-color: transparent; margin: 0 0 .25rem; }
.fg-sub { color: #94a3b8; margin-bottom: 1.3rem; }
[data-testid="stMetric"] { background: linear-gradient(145deg,#12203a,#0f172a); border: 1px solid #1e293b; border-radius: 16px; padding: 16px 18px; box-shadow: 0 8px 24px rgba(0,0,0,.3); }
[data-testid="stMetricLabel"] p { color: #94a3b8; font-size: .78rem; text-transform: uppercase; letter-spacing: .06em; }
[data-testid="stMetricValue"] { font-weight: 700; }
.stButton > button, .stDownloadButton > button { border-radius: 10px; border: 1px solid #334155; font-weight: 600; transition: all .15s ease; }
.stButton > button[kind="primary"] { background: linear-gradient(90deg,#06b6d4,#6366f1); border: none; color: #fff; }
.stButton > button:hover, .stDownloadButton > button:hover { transform: translateY(-1px); box-shadow: 0 6px 18px rgba(34,211,238,.25); }
[data-testid="stDataFrame"] { border: 1px solid #1e293b; border-radius: 12px; overflow: hidden; }
[data-testid="stPlotlyChart"] { background: rgba(15,23,42,.6); border: 1px solid #1e293b; border-radius: 16px; padding: 6px; }
[data-testid="stSidebar"] label[data-baseweb="radio"] { padding: 6px 10px; border-radius: 10px; }
[data-testid="stSidebar"] label[data-baseweb="radio"]:hover { background: #16233f; }
.banner { border-radius: 16px; padding: 18px 22px; margin: 14px 0; border: 1px solid; }
.banner h3 { margin: 0 0 4px; font-size: 1.25rem; }
.banner p { margin: 0; opacity: .85; }
.banner.FRAUD { background: linear-gradient(135deg,#4c0519,#1f0a12); border-color: #f43f5e; color: #fecdd3; }
.banner.REVIEW { background: linear-gradient(135deg,#451a03,#1c1207); border-color: #f59e0b; color: #fde68a; }
.banner.OK { background: linear-gradient(135deg,#052e2b,#07171a); border-color: #10b981; color: #a7f3d0; }
</style>"""


def inject():
    st.markdown(CSS, unsafe_allow_html=True)


def title(text, sub="", where=st):
    where.markdown(f'<div class="fg-title">{text}</div><div class="fg-sub">{sub}</div>', unsafe_allow_html=True)


def banner(kind, head, sub=""):
    st.markdown(f'<div class="banner {kind}"><h3>{head}</h3><p>{sub}</p></div>', unsafe_allow_html=True)
