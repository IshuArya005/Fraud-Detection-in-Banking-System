"""REST API:  uvicorn api:app --reload   then open http://127.0.0.1:8000/docs"""
import joblib, pandas as pd
from fastapi import FastAPI
from pydantic import BaseModel

art = joblib.load("model/fraud_model.joblib")
model = art["models"][art["best"]]
app = FastAPI(title="FraudGuard API")


class Txn(BaseModel):
    amount: float
    hour: int
    distance_from_home_km: float
    txns_last_24h: int
    account_age_days: int
    is_international: int
    card_present: int
    merchant_risk: float


@app.get("/health")
def health():
    return {"status": "ok", "model": art["best"]}


@app.post("/predict")
def predict(t: Txn, threshold: float = 0.5):
    p = float(model.predict_proba(pd.DataFrame([t.model_dump()])[art["features"]])[0, 1])
    decision = "FRAUD" if p >= threshold else "REVIEW" if p >= threshold * .6 else "OK"
    return {"fraud_probability": round(p, 4), "decision": decision}
