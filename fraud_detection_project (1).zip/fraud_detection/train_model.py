"""Train and compare 3 models, save everything the UI needs.
Uses synthetic banking data (about 2% fraud)."""
import os, joblib
import numpy as np, pandas as pd
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier, IsolationForest
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.utils.class_weight import compute_sample_weight
from sklearn.model_selection import train_test_split
from sklearn.metrics import (roc_auc_score, average_precision_score, roc_curve,
                             precision_recall_curve, precision_score, recall_score, f1_score)

os.makedirs("model", exist_ok=True); os.makedirs("data", exist_ok=True)


def make_synthetic(n=60000, fraud_rate=0.02, seed=42):
    rng = np.random.default_rng(seed)
    f = rng.random(n) < fraud_rate
    df = pd.DataFrame({
        "amount": np.where(f, rng.lognormal(4.8, 1.3, n), rng.lognormal(3.9, 1.2, n)).round(2),
        "hour": np.where(f, np.where(rng.random(n) < .5, rng.choice([0, 1, 2, 3, 4, 23], n), rng.integers(0, 24, n)), rng.integers(0, 24, n)),
        "distance_from_home_km": np.where(f, rng.exponential(60, n), rng.exponential(20, n)).round(1),
        "txns_last_24h": np.where(f, rng.poisson(4, n), rng.poisson(2.5, n)),
        "account_age_days": np.where(f, rng.integers(1, 1500, n), rng.integers(30, 4000, n)),
        "is_international": np.where(f, rng.random(n) < .35, rng.random(n) < .08).astype(int),
        "card_present": np.where(f, rng.random(n) < .4, rng.random(n) < .7).astype(int),
        "merchant_risk": np.where(f, rng.beta(3, 2.5, n), rng.beta(2, 4, n)).round(3),
    })
    df["Class"] = f.astype(int)
    return df


df = make_synthetic()
X, y = df.drop(columns="Class"), df["Class"]
X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)
sw = compute_sample_weight("balanced", y_tr)

models = {
    "Logistic Regression": make_pipeline(StandardScaler(), LogisticRegression(class_weight="balanced", max_iter=1000)),
    "Random Forest": RandomForestClassifier(n_estimators=200, class_weight="balanced_subsample",
                                            min_samples_leaf=2, n_jobs=-1, random_state=42),
    "Gradient Boosting": HistGradientBoostingClassifier(max_iter=200, random_state=42),
}
results, curves, probas = {}, {}, {}
for name, m in models.items():
    if name == "Gradient Boosting":
        m.fit(X_tr, y_tr, sample_weight=sw)
    else:
        m.fit(X_tr, y_tr)
    p = m.predict_proba(X_te)[:, 1]; probas[name] = p
    pred = (p >= .5).astype(int)
    results[name] = dict(roc_auc=roc_auc_score(y_te, p), pr_auc=average_precision_score(y_te, p),
                         precision=precision_score(y_te, pred, zero_division=0),
                         recall=recall_score(y_te, pred), f1=f1_score(y_te, pred))
    fpr, tpr, _ = roc_curve(y_te, p); pr, rc, _ = precision_recall_curve(y_te, p)
    curves[name] = dict(fpr=fpr[::10], tpr=tpr[::10], prec=pr[::10], rec=rc[::10])
    print(f"{name:20s} ROC {results[name]['roc_auc']:.3f}  PR {results[name]['pr_auc']:.3f}  "
          f"P {results[name]['precision']:.2f}  R {results[name]['recall']:.2f}")

best = max(results, key=lambda k: results[k]["pr_auc"])
print("Best model:", best)
iso = IsolationForest(n_estimators=200, random_state=42).fit(X_tr)   # unsupervised: no labels used
raw = -iso.score_samples(X_tr); iso_range = (float(np.percentile(raw, 1)), float(np.percentile(raw, 99.9)))
tr = X_tr.copy(); tr["Class"] = y_tr.values; tr.to_csv("data/train_set.csv", index=False)
te = X_te.copy(); te["Class"] = y_te.values; te.to_csv("data/test_set.csv", index=False)
joblib.dump(dict(models=models, best=best, features=list(X.columns), results=results, curves=curves,
                 y_te=y_te.values, proba=probas, iso=iso, iso_range=iso_range, medians=X_tr.median().to_dict()),
            "model/fraud_model.joblib")
print("Saved model/fraud_model.joblib and data/test_set.csv")
